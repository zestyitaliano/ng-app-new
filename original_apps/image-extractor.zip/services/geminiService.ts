import { GoogleGenAI, Type } from "@google/genai";
import { ExtractedImage } from "../types";
import { resolveUrl, detectImageType } from "../utils/urlHelpers";

const API_KEY = process.env.API_KEY || '';

export const extractImagesWithGemini = async (sourceCode: string, baseUrl: string): Promise<ExtractedImage[]> => {
  if (!API_KEY) {
    console.warn("No Gemini API Key provided. Skipping AI extraction.");
    return [];
  }

  // Truncate source code if excessively large to avoid context limit errors, 
  // though gemini-2.5-flash has a large window (1M tokens). 
  // We'll safeguard around 500k chars for responsiveness.
  const truncatedSource = sourceCode.length > 500000 
    ? sourceCode.substring(0, 500000) + "...(truncated)" 
    : sourceCode;

  const ai = new GoogleGenAI({ apiKey: API_KEY });

  const prompt = `
    I have provided the raw source code (HTML/JS) of a webpage below.
    Your task is to identify ALL image URLs found within this code.
    
    Look for:
    1. Standard <img> src attributes.
    2. CSS background-image urls.
    3. JSON data structures containing image links (common in React/SPA apps).
    4. Lazy loading attributes (data-src, etc.).
    5. JavaScript string variables that look like image paths.

    Return ONLY a JSON object with a single property 'urls' which is an array of strings.
    Exclude data:image base64 strings if they are longer than 200 characters.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: {
        parts: [
          { text: prompt },
          { text: `SOURCE CODE:\n${truncatedSource}` }
        ]
      },
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            urls: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: "List of absolute or relative image URLs found."
            }
          }
        }
      }
    });

    const jsonText = response.text;
    if (!jsonText) return [];

    const data = JSON.parse(jsonText);
    const urls: string[] = data.urls || [];

    return urls.map(url => {
        const fullUrl = resolveUrl(url, baseUrl);
        return {
            id: crypto.randomUUID(),
            url: fullUrl,
            type: detectImageType(fullUrl),
            source: 'gemini',
            isValid: true
        };
    });

  } catch (error) {
    console.error("Gemini Extraction Error:", error);
    return [];
  }
};