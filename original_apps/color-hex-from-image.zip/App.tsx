import React, { useState, useCallback } from 'react';
import { ImageUploader } from './components/ImageUploader';
import { ColorPickerCanvas } from './components/ColorPickerCanvas';
import { ColorInfo } from './components/ColorInfo';
import { ColorData } from './types';
import { RefreshCcw, Lock } from 'lucide-react';
import { Button } from './components/Button';

const App: React.FC = () => {
  const [imageSrc, setImageSrc] = useState<string | null>(null);
  const [selectedColor, setSelectedColor] = useState<ColorData | null>(null);
  const [hoverColor, setHoverColor] = useState<ColorData | null>(null);

  const handleImageLoad = useCallback((base64: string) => {
    setImageSrc(base64);
    setSelectedColor(null);
    setHoverColor(null);
  }, []);

  const handleClearColor = useCallback(() => {
    setSelectedColor(null);
  }, []);

  const handleRemoveImage = useCallback(() => {
    setImageSrc(null);
    setSelectedColor(null);
    setHoverColor(null);
  }, []);

  return (
    <div className="min-h-screen p-4 md:p-12 font-sans bg-white">
      <main className="max-w-5xl mx-auto space-y-12">
        
        {/* Header Section */}
        <header className="text-center space-y-4 py-8">
          <h1 className="text-4xl md:text-6xl font-extrabold tracking-tighter text-primary uppercase">
            Color Hex From Image
          </h1>
          <p className="text-xl font-medium text-slate-600 max-w-3xl mx-auto leading-relaxed">
            Extract colors from any image with pixel-perfect precision. <br className="hidden md:block"/>
            The easiest way to grab the hex code from your image!
          </p>
        </header>

        {/* Upload Section */}
        <section className="bg-white shadow-sm border border-slate-200">
          {!imageSrc ? (
            <div className="p-8">
               <ImageUploader onImageLoad={handleImageLoad} />
            </div>
          ) : (
            <div>
                <div className="p-4 bg-white border-b border-slate-200 flex justify-between items-center">
                    <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">Image Preview</span>
                    <Button 
                        variant="secondary" 
                        onClick={handleRemoveImage}
                        size="sm"
                        className="py-1 px-4 text-xs h-9"
                        icon={<RefreshCcw className="w-3 h-3"/>}
                    >
                        New Image
                    </Button>
                </div>
                <div className="p-8 bg-offwhite">
                    <ColorPickerCanvas 
                        imageSrc={imageSrc} 
                        onHoverColorChange={setHoverColor}
                        onSelectColor={setSelectedColor}
                    />
                </div>
            </div>
          )}
        </section>

        {/* Results Section - Only visible when image is loaded */}
        {imageSrc && (
            <section className="shadow-lg">
                <ColorInfo 
                    selectedColor={selectedColor} 
                    hoverColor={hoverColor}
                    onClear={handleClearColor}
                />
            </section>
        )}

        {/* Footer / Privacy */}
        <footer className="text-center pt-8 pb-8 border-t border-slate-200">
            <div className="flex items-center justify-center gap-2 text-sm font-medium text-slate-400">
                <Lock className="w-4 h-4" />
                <span>Images are processed locally in your browser and are not uploaded.</span>
            </div>
        </footer>

      </main>
    </div>
  );
};

export default App;