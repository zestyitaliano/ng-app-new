import { OCRResult, OCRLine, OCRWord } from '../types';

export const recognizeText = async (
  imageFile: File,
  language: string,
  onProgress: (progress: number) => void
): Promise<OCRResult> => {
  if (!window.Tesseract) {
    throw new Error('Tesseract library not loaded.');
  }

  try {
    const result = await window.Tesseract.recognize(
      imageFile,
      language,
      {
        logger: (m: any) => {
          if (m.status === 'recognizing text') {
            // Tesseract progress is 0-1, we convert to 0-100
            onProgress(Math.floor(m.progress * 100));
          }
        },
      }
    );

    // Map Tesseract structure to our types
    const lines: OCRLine[] = result.data.lines.map((line: any) => ({
      text: line.text,
      words: line.words.map((word: any) => ({
        text: word.text,
        confidence: word.confidence,
      })),
    }));

    return {
      text: result.data.text,
      confidence: result.data.confidence,
      lines: lines,
    };
  } catch (error) {
    console.error("OCR Error:", error);
    throw new Error('Failed to process image.');
  }
};