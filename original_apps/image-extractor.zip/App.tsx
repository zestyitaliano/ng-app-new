import React, { useState } from 'react';
import { Search, Globe, Code2, Info, ShieldAlert, Filter, Download, FileCode, X, Copy, CheckCircle, XCircle, Loader2 } from 'lucide-react';
import { ExtractedImage, ExtractionStatus, ExtractionStats } from './types';
import { normalizeUrl, findUrlsInText, deduplicateImages, checkImageAvailability } from './utils/urlHelpers';
import { fetchPageSource } from './services/proxyService';
import { downloadAsZip } from './utils/downloadHelpers';
import { Button } from './components/Button';
import { ImageCard } from './components/ImageCard';

const App = () => {
  const [inputUrl, setInputUrl] = useState('');
  const [status, setStatus] = useState<ExtractionStatus>(ExtractionStatus.IDLE);
  const [images, setImages] = useState<ExtractedImage[]>([]);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [filter, setFilter] = useState<'all' | 'jpg' | 'png' | 'svg' | 'webp'>('all');
  const [isDownloading, setIsDownloading] = useState(false);
  const [isRegexPanelOpen, setIsRegexPanelOpen] = useState(false);

  // Stats
  const stats: ExtractionStats = {
    totalFound: images.length,
    regexFound: images.filter(i => i.source === 'regex').length,
    unique: new Set(images.map(i => i.url)).size
  };

  const handleExtract = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!inputUrl) return;

    setStatus(ExtractionStatus.FETCHING_SOURCE);
    setImages([]);
    setErrorMsg(null);

    const cleanUrl = normalizeUrl(inputUrl);

    try {
      // 1. Fetch Source
      const sourceCode = await fetchPageSource(cleanUrl);
      
      // 2. Local Regex Extraction (Fast)
      setStatus(ExtractionStatus.EXTRACTING_REGEX);
      const regexImages = findUrlsInText(sourceCode, cleanUrl);
      // Deduplicate regex results immediately
      const dedupedRegex = deduplicateImages(regexImages);
      
      // 3. Validate Images (Check availability)
      setStatus(ExtractionStatus.VALIDATING);
      const validatedImages = await Promise.all(dedupedRegex.map(async (img) => {
          const isValid = await checkImageAvailability(img.url);
          return { ...img, isValid };
      }));

      setImages(validatedImages); 

      setStatus(ExtractionStatus.COMPLETED);

    } catch (err: any) {
      console.error(err);
      setErrorMsg(err.message || "An unknown error occurred");
      setStatus(ExtractionStatus.ERROR);
    }
  };

  const handleDownloadAll = async () => {
    // Only download valid images
    const validImages = filteredImages.filter(img => img.isValid);
    if (validImages.length === 0) return;
    
    setIsDownloading(true);
    try {
      await downloadAsZip(validImages);
    } catch (error) {
      console.error("Download failed", error);
      setErrorMsg("Failed to generate zip file. Some images might be inaccessible.");
    } finally {
      setIsDownloading(false);
    }
  };

  const filteredImages = images.filter(img => filter === 'all' || img.type === filter);
  const regexMatches = images.filter(i => i.source === 'regex');

  // Determine loading text
  let loadingText = '';
  if (status === ExtractionStatus.FETCHING_SOURCE) loadingText = 'Fetching Source...';
  if (status === ExtractionStatus.EXTRACTING_REGEX) loadingText = 'Scanning Patterns...';
  if (status === ExtractionStatus.VALIDATING) loadingText = 'Validating Assets...';

  const isLoading = status !== ExtractionStatus.IDLE && status !== ExtractionStatus.COMPLETED && status !== ExtractionStatus.ERROR;

  return (
    <div className="min-h-screen bg-white text-slate-900 selection:bg-[#1982c4] selection:text-white border-t-4 border-[#1982c4]">
      
      {/* Header */}
      <header className="bg-white border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="h-20 flex items-center justify-between gap-4">
            
            {/* Logo */}
            <div className="flex items-center gap-2 select-none shrink-0">
              <div className="bg-[#1982c4] p-1.5 rounded-sm">
                <Code2 className="w-5 h-5 text-white" />
              </div>
              <div className="flex flex-col justify-center">
                <h1 className="text-xl font-extrabold text-[#1982c4] tracking-tighter leading-none uppercase">SourceLens</h1>
                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest leading-none mt-0.5">Asset Extractor</p>
              </div>
            </div>

            {/* Search Bar Group - Height Normalized to h-10 */}
            <div className="flex-1 max-w-2xl flex items-center justify-end gap-3">
              <form onSubmit={handleExtract} className="flex-1 flex items-stretch h-10 w-full">
                <div className="relative flex-1 group">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Globe className="h-4 w-4 text-slate-400 group-focus-within:text-[#1982c4] transition-colors" />
                  </div>
                  <input
                    type="text"
                    value={inputUrl}
                    onChange={(e) => setInputUrl(e.target.value)}
                    placeholder="Paste URL (e.g. https://www.canva.com/...)"
                    className="block w-full pl-10 pr-4 h-full bg-[#efefef] border-none text-slate-900 placeholder-slate-500 text-sm focus:outline-none focus:ring-2 focus:ring-inset focus:ring-[#1982c4] transition-all font-medium"
                  />
                </div>
                <Button 
                  type="submit" 
                  variant="primary"
                  className="h-full px-6 rounded-none text-xs"
                  isLoading={isLoading}
                  icon={<Search size={14} />}
                >
                  {isLoading ? (status === ExtractionStatus.VALIDATING ? 'VALIDATING' : 'WORKING') : 'EXTRACT'}
                </Button>
              </form>
              
              {/* Regex Panel Toggle */}
              <button 
                onClick={() => setIsRegexPanelOpen(true)}
                className="h-10 w-10 flex items-center justify-center bg-[#ffca3a] hover:bg-[#e0b132] text-slate-900 transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[#ffca3a]"
                title="Open Regex Debugger"
              >
                 <FileCode size={18} />
              </button>
            </div>
          </div>
        </div>
        
        {/* Progress Bar (if active) */}
        {isLoading && (
          <div className="absolute bottom-0 left-0 w-full h-1 bg-[#efefef] overflow-hidden transform translate-y-full">
             <div className="h-full bg-gradient-to-r from-[#1982c4] via-[#ffca3a] to-[#1982c4] w-full animate-progress origin-left"></div>
          </div>
        )}
      </header>

      {/* Regex Side Panel */}
      <>
        {/* Backdrop */}
        {isRegexPanelOpen && (
            <div 
                className="fixed inset-0 bg-slate-900/20 backdrop-blur-sm z-50"
                onClick={() => setIsRegexPanelOpen(false)}
            />
        )}
        
        {/* Panel */}
        <div className={`fixed top-0 right-0 h-full w-full md:w-[450px] bg-white border-l-2 border-[#1982c4] z-[60] transform transition-transform duration-300 ease-in-out ${isRegexPanelOpen ? 'translate-x-0' : 'translate-x-full'} flex flex-col shadow-xl`}>
            {/* Panel Header */}
            <div className="p-6 border-b border-slate-200 flex justify-between items-center bg-white sticky top-0 z-10">
                <h2 className="text-xl font-extrabold text-[#1982c4] uppercase flex items-center gap-3">
                    <FileCode className="text-[#ffca3a]" size={24} /> 
                    Regex Debugger
                </h2>
                <button 
                  onClick={() => setIsRegexPanelOpen(false)} 
                  className="text-slate-400 hover:text-[#ff595e] transition-colors p-2 hover:bg-[#efefef]"
                >
                    <X size={24} />
                </button>
            </div>
            
            {/* Panel Controls */}
            <div className="p-6 bg-[#fafafa] border-b border-slate-200">
                 <label className="text-xs font-bold uppercase text-slate-500 mb-2 block tracking-wider">Target Source URL</label>
                 <div className="flex gap-0 mb-4 bg-white">
                    <input 
                        type="text" 
                        value={inputUrl} 
                        onChange={(e) => setInputUrl(e.target.value)}
                        className="flex-1 px-3 py-3 bg-white border border-slate-200 focus:border-[#1982c4] focus:outline-none text-sm font-medium font-mono text-slate-600"
                        placeholder="https://example.com"
                    />
                 </div>
                 <Button 
                    onClick={() => handleExtract()} 
                    className="w-full h-10" 
                    variant="primary"
                    disabled={isLoading}
                 >
                    {isLoading ? loadingText || 'Running...' : 'Run Regex Pattern Match'}
                 </Button>
            </div>

            {/* Panel Results */}
            <div className="flex-1 overflow-y-auto p-6 bg-slate-50">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-xs font-bold uppercase text-slate-400 tracking-widest">Matched Results</h3>
                  <span className="text-xs font-bold bg-[#1982c4] text-white px-2 py-0.5">{regexMatches.length}</span>
                </div>

                {regexMatches.length === 0 ? (
                    <div className="text-center text-slate-400 py-10 border-2 border-dashed border-slate-200 bg-white">
                        <FileCode className="mx-auto mb-2 opacity-20" size={32} />
                        <p className="text-sm font-bold uppercase">No matches found</p>
                        <p className="text-xs mt-1 px-4">Enter a URL and run the pattern matcher to see raw results.</p>
                    </div>
                ) : (
                    <div className="space-y-3">
                        {regexMatches.map((img, idx) => (
                            <div key={img.id} className={`bg-white border p-3 transition-all group ${img.isValid ? 'border-slate-200 hover:border-[#1982c4]' : 'border-[#ff595e]/30 bg-red-50'}`}>
                                <div className="flex justify-between items-start gap-3">
                                    <div className="flex-1 min-w-0">
                                        <div className="flex items-center gap-2 mb-1">
                                          <span className="text-[10px] font-bold text-[#ffca3a] bg-[#ffca3a]/10 px-1.5 uppercase tracking-wider border border-[#ffca3a]/20">Match #{idx + 1}</span>
                                          <span className="text-[10px] font-bold text-slate-400 uppercase">{img.type}</span>
                                          {!img.isValid && (
                                              <span className="text-[10px] font-bold text-[#ff595e] flex items-center gap-1">
                                                <XCircle size={10} /> Invalid
                                              </span>
                                          )}
                                        </div>
                                        <p className="text-xs font-mono text-slate-600 break-all leading-relaxed select-all">
                                            {img.url}
                                        </p>
                                    </div>
                                    <button 
                                        onClick={() => navigator.clipboard.writeText(img.url)}
                                        className="text-slate-300 hover:text-[#1982c4] hover:bg-[#efefef] transition-all p-1.5"
                                        title="Copy URL"
                                    >
                                        <Copy size={14} />
                                    </button>
                                </div>
                                <div className="mt-2 pt-2 border-t border-dashed border-slate-200 flex justify-between items-center">
                                     <span className="text-[10px] font-bold text-slate-400 uppercase flex items-center gap-1">
                                        Source: <span className="text-slate-600">Regex Engine</span>
                                     </span>
                                     {img.isValid && (
                                       <a href={img.url} target="_blank" rel="noopener noreferrer" className="text-[10px] font-bold text-[#1982c4] hover:underline">
                                          OPEN LINK
                                       </a>
                                     )}
                                </div>
                            </div>
                        ))}
                    </div>
                )}
            </div>
        </div>
      </>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">

        {/* Status Messages */}
        {status === ExtractionStatus.ERROR && (
          <div className="mb-8 p-6 bg-[#ff595e]/10 border-l-4 border-[#ff595e] flex items-start gap-4">
            <ShieldAlert className="w-6 h-6 text-[#ff595e] shrink-0 mt-0.5" />
            <div>
              <h3 className="text-[#ff595e] font-bold text-lg">Extraction Failed</h3>
              <p className="text-slate-600 mt-1 font-medium">{errorMsg}</p>
              <p className="text-slate-500 text-sm mt-2">Try a different URL or check if the site allows cross-origin fetching.</p>
            </div>
          </div>
        )}

        {status === ExtractionStatus.IDLE && images.length === 0 && (
          <div className="min-h-[60vh] flex flex-col items-center justify-center text-center">
            
            {/* Hero Icon */}
            <div className="relative mb-8 group">
              <div className="w-24 h-24 bg-slate-100 flex items-center justify-center relative z-10">
                <Search className="w-10 h-10 text-[#1982c4] stroke-[2.5]" />
              </div>
              {/* Decorative corner accent */}
              <div className="absolute -bottom-2 -right-2 w-8 h-8 border-r-4 border-b-4 border-[#1982c4] z-0"></div>
            </div>

            <h2 className="text-5xl font-black text-slate-900 mb-4 tracking-tight uppercase">Ready to Reveal</h2>
            <p className="text-slate-500 max-w-lg mx-auto mb-12 text-lg font-medium">
              Paste any URL above to extract hidden image assets using our fast regex engine.
            </p>
            
            <div className="flex justify-center">
               <span className="flex items-center gap-2 text-xs font-bold text-[#ffca3a] uppercase tracking-[0.2em] hover:text-[#e0b132] cursor-default transition-colors">
                  <span className="text-[#1982c4] font-mono font-bold">&lt;/&gt;</span> View Source Analysis
               </span>
            </div>
          </div>
        )}

        {/* Results Area */}
        {images.length > 0 && (
          <div className="animate-fade-in-up">
            
            {/* Toolbar */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-6 mb-8 border-b border-slate-200 pb-6">
               <div className="flex items-center gap-6">
                  <h2 className="text-2xl font-extrabold text-slate-900 flex items-center gap-3">
                    Found Assets
                    <span className="text-sm font-bold text-white bg-[#1982c4] px-3 py-1">
                      {images.filter(i => i.isValid).length} / {images.length}
                    </span>
                  </h2>
               </div>

               <div className="flex flex-wrap items-center gap-4">
                  {/* Filter Group */}
                  <div className="flex items-center bg-slate-100 p-1">
                      <Filter size={16} className="text-slate-400 ml-2 mr-2" />
                      {(['all', 'jpg', 'png', 'svg', 'webp'] as const).map((type) => (
                        <button
                          key={type}
                          onClick={() => setFilter(type)}
                          className={`px-4 py-1.5 text-xs font-bold uppercase tracking-wider transition-all ${
                            filter === type 
                              ? 'bg-white text-[#1982c4] shadow-sm' 
                              : 'text-slate-500 hover:text-slate-900 hover:bg-white/50'
                          }`}
                        >
                          {type}
                        </button>
                      ))}
                  </div>

                  {/* Download All Button */}
                   <Button 
                      variant="primary"
                      onClick={handleDownloadAll}
                      isLoading={isDownloading}
                      icon={<Download size={16} />}
                      className="bg-[#1982c4] hover:bg-[#146c9e] h-10"
                      disabled={filteredImages.filter(i => i.isValid).length === 0}
                   >
                      Download All
                   </Button>
               </div>
            </div>

            {/* Grid */}
            {filteredImages.length === 0 ? (
               <div className="text-center py-24 border-2 border-dashed border-slate-200 bg-slate-50">
                  <p className="text-slate-400 font-bold text-lg">No images found for this filter.</p>
               </div>
            ) : (
              <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
                {filteredImages.map((img) => (
                  <ImageCard key={img.id} image={img} />
                ))}
              </div>
            )}
            
            <div className="mt-12 text-center">
              <p className="text-slate-400 text-xs font-bold uppercase tracking-widest flex items-center justify-center gap-2">
                <Info size={14} />
                Some images may be protected by CORS. Links remain valid.
              </p>
            </div>

          </div>
        )}

      </main>
      
      <style>{`
        @keyframes progress {
          0% { transform: scaleX(0); }
          50% { transform: scaleX(0.5); }
          100% { transform: scaleX(1); }
        }
        .animate-progress {
          animation: progress 2s infinite ease-in-out;
        }
        .animate-fade-in-up {
          animation: fadeInUp 0.5s ease-out forwards;
        }
        @keyframes fadeInUp {
          from { opacity: 0; transform: translateY(20px); }
          to { opacity: 1; transform: translateY(0); }
        }
      `}</style>
    </div>
  );
};

export default App;
