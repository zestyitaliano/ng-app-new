import { GoogleGenAI } from "@google/genai";
import { FontMetadata, AiActionType } from "../types";

const getClient = () => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) throw new Error("API Key not found");
  return new GoogleGenAI({ apiKey });
};

export const generateFontInsights = async (
  metadata: FontMetadata, 
  action: AiActionType
): Promise<string> => {
  const ai = getClient();
  const model = "gemini-3-flash-preview";
  
  const fontDescription = `Font Family: "${metadata.family}", Subfamily: "${metadata.subfamily}", Manufacturer: "${metadata.manufacturer || 'Unknown'}".`;

  let prompt = "";

  switch (action) {
    case AiActionType.PAIRINGS:
      prompt = `
        I have a font file with these details: ${fontDescription}.
        Please suggest 3 specific fonts (preferably from Google Fonts) that pair excellently with this font.
        For each pairing, explain *why* it works (contrast, harmony, etc.).
        Also suggest a use-case for the combination (e.g., "Editorial Blog", "Tech Dashboard").
        Output in Markdown.
      `;
      break;
    case AiActionType.CSS:
      prompt = `
        I have a font named "${metadata.family}".
        Generate a robust CSS @font-face declaration for it. 
        Then, provide 3 examples of CSS classes using this font for a Heading, a Body paragraph, and a Button, 
        including nice modern styling (colors, line-heights, letter-spacing) that suits a "${metadata.subfamily}" style.
        Output in Markdown with code blocks.
      `;
      break;
    case AiActionType.VIBE:
      prompt = `
        Analyze the "vibe" and personality of a font with these details: ${fontDescription}.
        Who is the target audience? What kind of brands would use this?
        Provide a 5-color palette (Hex codes) that matches this font's energy.
        Output in Markdown.
      `;
      break;
  }

  try {
    const response = await ai.models.generateContent({
      model,
      contents: prompt,
      config: {
          thinkingConfig: { thinkingBudget: 0 } // Speed over deep thought for this
      }
    });
    return response.text || "No response generated.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "Failed to generate AI insights. Please try again.";
  }
};