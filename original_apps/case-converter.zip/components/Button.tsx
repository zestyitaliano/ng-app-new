import React from 'react';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'outline' | 'ghost';
  size?: 'sm' | 'md' | 'lg';
  isActive?: boolean;
}

export const Button: React.FC<ButtonProps> = ({ 
  children, 
  variant = 'primary', 
  size = 'md', 
  isActive = false,
  className = '',
  ...props 
}) => {
  // Removed rounded classes, added border-2 where relevant for bolder look
  const baseStyles = "inline-flex items-center justify-center font-bold transition-all focus:outline-none focus:ring-2 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed";
  
  const variants = {
    primary: "bg-primary text-white hover:bg-primaryHover focus:ring-primary border-2 border-transparent",
    // Secondary is now the Case Option button: White default, Yellow Hover
    secondary: "bg-white text-slate-700 border-2 border-slate-200 hover:bg-secondary hover:border-secondary hover:text-slate-900 focus:ring-primary",
    // Outline is for Clear/Secondary actions
    outline: "bg-transparent border-2 border-slate-300 text-slate-700 hover:bg-offWhite hover:border-slate-400 focus:ring-slate-400",
    ghost: "bg-transparent text-slate-600 hover:bg-offWhite focus:ring-slate-400",
  };

  // Active state overrides
  const activeStyles = isActive 
    ? "bg-primary border-primary text-white hover:bg-primaryHover hover:border-primaryHover hover:text-white" 
    : "";

  const sizes = {
    sm: "px-3 py-1.5 text-xs",
    md: "px-4 py-2 text-sm",
    lg: "px-6 py-3 text-base",
  };

  return (
    <button 
      className={`${baseStyles} ${variants[variant]} ${sizes[size]} ${activeStyles} ${className}`}
      {...props}
    >
      {children}
    </button>
  );
};