
/**
 * AI features have been removed from the application.
 * This file is kept for architectural consistency but contains no functionality.
 */
export const generateTags = async (): Promise<string[]> => {
  return [];
};

export const generateIconSvg = async (): Promise<string> => {
  return '';
};
