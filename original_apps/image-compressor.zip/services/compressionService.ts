import { CompressionSettings, CompressionResult } from "../types";

export const compressImage = async (
  file: File,
  settings: CompressionSettings
): Promise<CompressionResult> => {
  return new Promise((resolve, reject) => {
    const img = new Image();
    const objectUrl = URL.createObjectURL(file);

    img.onload = () => {
      URL.revokeObjectURL(objectUrl);

      // Calculate dimensions
      let width = img.width;
      let height = img.height;

      if (settings.resize && settings.maxWidth > 0) {
        if (width > settings.maxWidth || height > settings.maxWidth) {
            const ratio = width / height;
            if (ratio > 1) {
                // Landscape
                width = settings.maxWidth;
                height = width / ratio;
            } else {
                // Portrait or Square
                height = settings.maxWidth;
                width = height * ratio;
            }
        }
      }

      const canvas = document.createElement('canvas');
      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext('2d');

      if (!ctx) {
        reject(new Error('Canvas context unavailable. Browser may be out of memory.'));
        return;
      }

      // Handle Background for JPEG conversion (Transparency becomes black otherwise)
      // Also apply if converting PNG/WebP (transparent) to JPEG
      const isGoingToJpeg = settings.format === 'image/jpeg' || (settings.format === 'original' && file.type === 'image/jpeg');
      
      if (isGoingToJpeg) {
        ctx.fillStyle = '#FFFFFF';
        ctx.fillRect(0, 0, width, height);
      }

      // Draw image
      // Note: Modern browsers generally handle EXIF orientation automatically when drawing an Image to Canvas.
      // Explicit EXIF parsing and rotation is heavy logic. 
      // If "Strip Metadata" is on, the canvas toBlob simply won't include the EXIF tags, effectively "baking" the rotation if the browser respected it on draw.
      ctx.drawImage(img, 0, 0, width, height);

      // Determine output MIME type
      let mimeType = file.type;
      if (settings.format !== 'original') {
        mimeType = settings.format;
      }

      // Handle GIF edge case (Canvas only draws first frame)
      let warning: string | undefined;
      if (file.type === 'image/gif') {
         // Canvas cannot compress GIF animations, it will save a static frame. 
         warning = "GIF animation flattened to first frame.";
      }

      canvas.toBlob(
        (blob) => {
          if (blob) {
            resolve({
              blob,
              width,
              height,
              warning
            });
          } else {
            reject(new Error(`Failed to encode image to ${mimeType}.`));
          }
        },
        mimeType,
        settings.quality
      );
    };

    img.onerror = () => {
      URL.revokeObjectURL(objectUrl);
      reject(new Error('Failed to decode image. File is corrupt or format unsupported.'));
    };

    img.src = objectUrl;
  });
};