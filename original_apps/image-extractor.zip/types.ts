export interface ExtractedImage {
  id: string;
  url: string;
  type: 'jpg' | 'png' | 'gif' | 'svg' | 'webp' | 'unknown';
  source: 'regex' | 'gemini';
  isValid: boolean;
}

export enum ExtractionStatus {
  IDLE = 'IDLE',
  FETCHING_SOURCE = 'FETCHING_SOURCE',
  EXTRACTING_REGEX = 'EXTRACTING_REGEX',
  VALIDATING = 'VALIDATING',
  COMPLETED = 'COMPLETED',
  ERROR = 'ERROR'
}

export interface ExtractionStats {
  totalFound: number;
  regexFound: number;
  unique: number;
}