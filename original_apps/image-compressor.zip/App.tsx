import React, { useState, useEffect, useRef } from 'react';
import JSZip from 'jszip';
import DropZone from './components/DropZone';
import SettingsPanel from './components/SettingsPanel';
import ResultRow from './components/ResultRow';
import { DEFAULT_SETTINGS, MAX_FILE_SIZE_WARNING } from './constants';
import { CompressionSettings, ImageItem } from './types';
import { compressImage } from './services/compressionService';
import { formatBytes, generateFilename } from './utils/formatters';

export default function App() {
  const [settings, setSettings] = useState<CompressionSettings>(DEFAULT_SETTINGS);
  const [queue, setQueue] = useState<ImageItem[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const processingRef = useRef(false);

  // Add files to queue
  const handleFilesAdded = (files: File[]) => {
    const newItems: ImageItem[] = files.map((file) => ({
      id: Math.random().toString(36).substring(7),
      file,
      previewUrl: URL.createObjectURL(file),
      originalSize: file.size,
      status: 'idle',
      extension: file.name.split('.').pop() || '',
    }));
    setQueue((prev) => [...prev, ...newItems]);
  };

  // Clear all
  const handleClear = () => {
    // Revoke object URLs to avoid leaks
    queue.forEach(item => URL.revokeObjectURL(item.previewUrl));
    setQueue([]);
    // Reset processing state just in case
    processingRef.current = false;
    setIsProcessing(false);
  };

  const handleStartCompression = () => {
    // Set all items to pending to trigger the processing loop
    // This allows re-processing items if settings changed
    // We filter to ensure we don't mess up if something was weirdly already processing, though button is disabled
    setQueue(prev => prev.map(item => ({
        ...item,
        status: 'pending',
        error: undefined,
        warning: undefined
    })));
  };

  // Processor Loop
  useEffect(() => {
    const processQueue = async () => {
      // Prevent concurrent processing of the same item or multiple items
      if (processingRef.current) return;
      
      const pendingItem = queue.find(item => item.status === 'pending');
      
      // If no pending items, we are done
      if (!pendingItem) {
        setIsProcessing(false);
        return;
      }

      // Start processing
      processingRef.current = true;
      setIsProcessing(true);

      // Mark this specific item as processing in UI
      setQueue(prev => prev.map(item => 
        item.id === pendingItem.id ? { ...item, status: 'processing' } : item
      ));

      try {
        // Warning for huge files
        if (pendingItem.file.size > MAX_FILE_SIZE_WARNING) {
            console.warn("Large file detected, this might be slow.");
        }

        const result = await compressImage(pendingItem.file, settings);
        
        // Mark as done
        setQueue(prev => prev.map(item => 
            item.id === pendingItem.id ? {
                ...item,
                status: 'done',
                compressedBlob: result.blob,
                compressedSize: result.blob.size,
                warning: result.warning
            } : item
        ));

      } catch (error) {
        console.error("Compression failed", error);
        setQueue(prev => prev.map(item => 
            item.id === pendingItem.id ? {
                ...item,
                status: 'error',
                error: 'Failed to compress'
            } : item
        ));
      } finally {
        // Release lock. 
        // Important: We do NOT recursively call processQueue here. 
        // The setQueue calls above will trigger a re-render, firing this Effect again.
        processingRef.current = false;
      }
    };

    processQueue();
  }, [queue, settings]); 

  // Calculate totals
  const totalOriginal = queue.reduce((acc, item) => acc + item.originalSize, 0);
  const totalCompressed = queue.reduce((acc, item) => acc + (item.compressedSize || 0), 0);
  const completedCount = queue.filter(i => i.status === 'done').length;
  const isAllDone = completedCount === queue.length && queue.length > 0;
  // Can compress if we have items and we aren't currently processing
  // (Or if we are idle/done, basically not 'processing')
  const hasItems = queue.length > 0;

  // Download All Logic
  const handleDownloadAll = async () => {
    if (!isAllDone) return;
    
    const zip = new JSZip();
    const folder = zip.folder("compressed-images");
    
    queue.forEach(item => {
        if (item.compressedBlob && folder) {
            const filename = generateFilename(item.file.name, item.compressedBlob, settings.format);
            folder.file(filename, item.compressedBlob);
        }
    });

    try {
        const content = await zip.generateAsync({ type: "blob" });
        const url = URL.createObjectURL(content);
        const link = document.createElement('a');
        link.href = url;
        link.download = "images-compressed.zip";
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        setTimeout(() => URL.revokeObjectURL(url), 100);
    } catch (e) {
        console.error("Failed to zip", e);
        alert("Could not create zip file.");
    }
  };

  return (
    <div className="min-h-screen pb-12 px-4 sm:px-6 lg:px-8 bg-white">
      {/* Header / Hero */}
      <header className="max-w-4xl mx-auto pt-12 pb-10 text-center">
        <h1 className="text-4xl sm:text-6xl font-extrabold tracking-tight text-[#1982c4] mb-6 uppercase">
          Image Compressor
        </h1>
        <div className="prose prose-lg mx-auto text-slate-600">
          <p className="mb-4">
            Welcome to the wonderful world of image compression, where your digital dreams come true with smaller file sizes and faster loading times.
          </p>
          <p>
            Whether you’re a graphic designer perfecting a masterpiece or a web designer ensuring your site loads at lightning speed, compressing images is a must-have skill in your toolkit. At <strong className="text-[#1982c4]">No Gatekeeping</strong>, we’ve crafted an image compressor that’s not only efficient but also incredibly user-friendly. Let’s dive into the magic of image compression and explore why it’s essential for your creative projects.
          </p>
        </div>
      </header>

      {/* Main Tool Area */}
      <main className="max-w-5xl mx-auto">
        <div className="bg-white rounded-none shadow-xl border border-slate-200 p-6 md:p-8">
          <h2 className="text-2xl font-bold text-slate-800 mb-6 uppercase border-b-4 border-[#ffca3a] inline-block pb-1">
            Image Compressor
          </h2>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            {/* Left Col: Upload & Stats */}
            <div className="lg:col-span-7 space-y-6">
              <div className="h-[300px]">
                <DropZone onFilesAdded={handleFilesAdded} isProcessing={isProcessing} />
              </div>
              
              {/* Summary Bar (Extra Credit) */}
              {queue.length > 0 && (
                <div className="bg-[#1982c4] text-white rounded-none p-4 flex justify-between items-center shadow-md border-l-8 border-[#ffca3a]">
                   <div>
                      <span className="text-xs text-white/80 uppercase tracking-wider font-semibold">Total Savings</span>
                      <div className="text-xl font-bold">
                        {completedCount > 0 && totalCompressed > 0 
                            ? formatBytes(totalOriginal - totalCompressed) 
                            : '0 B'}
                      </div>
                   </div>
                   <div className="text-right">
                      <div className="text-xs text-white/80">
                        {isProcessing ? 'Processing...' : (isAllDone ? 'Completed' : 'Pending')}
                      </div>
                      <div className="font-mono text-lg">
                        {completedCount} / {queue.length}
                      </div>
                   </div>
                </div>
              )}
            </div>

            {/* Right Col: Settings */}
            <div className="lg:col-span-5">
              <SettingsPanel 
                settings={settings} 
                onChange={setSettings} 
                disabled={isProcessing}
                onCompress={handleStartCompression}
                canCompress={hasItems && !isProcessing}
              />
            </div>
          </div>

          {/* Results List */}
          {queue.length > 0 && (
            <div className="mt-10">
              <div className="flex items-center justify-between mb-4">
                 <h3 className="text-lg font-semibold text-slate-700">Results</h3>
                 {isProcessing && (
                     <span className="text-sm text-[#1982c4] animate-pulse font-medium">
                        Compressing images, please wait...
                     </span>
                 )}
              </div>
              
              <div className="space-y-3 max-h-[600px] overflow-y-auto pr-2">
                {queue.map((item) => (
                  <ResultRow 
                    key={item.id} 
                    item={item} 
                    settingsFormat={settings.format}
                  />
                ))}
              </div>

              {/* Action Buttons */}
              <div className="flex gap-4 mt-8 pt-6 border-t border-slate-100 justify-end">
                <button
                    onClick={handleClear}
                    disabled={isProcessing}
                    className="px-6 py-2.5 rounded-none text-[#ff595e] font-bold border-2 border-[#ff595e] hover:bg-[#ff595e] hover:text-white disabled:opacity-50 transition-colors uppercase tracking-wide text-sm"
                >
                    Clear
                </button>
                <button
                    onClick={handleDownloadAll}
                    disabled={!isAllDone}
                    className={`
                        px-8 py-2.5 rounded-none font-bold shadow-lg text-white transition-all transform active:scale-95 uppercase tracking-wide text-sm
                        ${isAllDone 
                            ? 'bg-[#1982c4] hover:bg-[#156a9e] hover:shadow-xl' 
                            : 'bg-slate-400 cursor-not-allowed'}
                    `}
                >
                    Download All
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Privacy Note */}
        <div className="text-center mt-12 mb-8">
            <p className="text-sm text-slate-400 flex items-center justify-center gap-2">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className="w-4 h-4 text-[#ffca3a]">
                    <path fillRule="evenodd" d="M10 1a4.5 4.5 0 0 0-4.5 4.5V9H5a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-6a2 2 0 0 0-2-2h-.5V5.5A4.5 4.5 0 0 0 10 1Zm3 8V5.5a3 3 0 1 0-6 0V9h6Z" clipRule="evenodd" />
                </svg>
                All compression happens locally in your browser. Images are not uploaded.
            </p>
        </div>
      </main>
    </div>
  );
}