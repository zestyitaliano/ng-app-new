import React from 'react';
import { Loader2 } from 'lucide-react';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'ghost';
  isLoading?: boolean;
  icon?: React.ReactNode;
}

export const Button: React.FC<ButtonProps> = ({ 
  children, 
  variant = 'primary', 
  isLoading, 
  icon,
  className = '', 
  disabled,
  ...props 
}) => {
  const baseStyles = "inline-flex items-center justify-center font-bold transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[#1982c4] disabled:opacity-50 disabled:cursor-not-allowed uppercase tracking-wide text-sm";
  
  const variants = {
    primary: "bg-[#1982c4] hover:bg-[#146c9e] text-white border-2 border-transparent",
    secondary: "bg-[#ffca3a] hover:bg-[#e0b132] text-slate-900 border-2 border-transparent",
    ghost: "bg-transparent hover:bg-[#efefef] text-slate-600 hover:text-[#1982c4] border-2 border-transparent hover:border-[#efefef]"
  };

  return (
    <button 
      className={`${baseStyles} ${variants[variant]} ${className}`}
      disabled={disabled || isLoading}
      {...props}
    >
      {isLoading ? (
        <>
          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
          Processing...
        </>
      ) : (
        <>
          {icon && <span className="mr-2">{icon}</span>}
          {children}
        </>
      )}
    </button>
  );
};
