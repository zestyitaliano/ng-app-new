
import { GoogleGenAI, Type } from "@google/genai";
import { AISuggestion } from "../types";

// Always initialize GoogleGenAI with a named parameter for apiKey.
// Use process.env.API_KEY directly as per project guidelines.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

/**
 * Uses Gemini AI to suggest effective UTM parameters based on website URL and product description.
 */
export async function suggestUTMParameters(websiteUrl: string, productDescription: string): Promise<AISuggestion[]> {
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Suggest 3 effective UTM campaign combinations for the following website/product.
    Website: ${websiteUrl}
    Context: ${productDescription}
    
    Ensure the suggestions follow marketing best practices (lowercase, descriptive, standard sources like 'facebook', 'newsletter', 'linkedin').`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            campaignSource: { type: Type.STRING },
            campaignMedium: { type: Type.STRING },
            campaignName: { type: Type.STRING },
            reasoning: { type: Type.STRING }
          },
          required: ["campaignSource", "campaignMedium", "campaignName", "reasoning"]
        }
      }
    }
  });

  try {
    // Correctly accessing the .text property from the response object.
    const jsonStr = response.text.trim();
    return JSON.parse(jsonStr);
  } catch (e) {
    console.error("Failed to parse AI response", e);
    return [];
  }
}
