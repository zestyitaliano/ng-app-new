import React, { useState, useCallback, useRef } from 'react';
import { FontFile, FontFormat } from './types';
import { parseFontFile, convertFont } from './services/fontService';
import { FontCard } from './components/FontCard';
import { Button } from './components/Button';
import { Upload, Type, AlertCircle, Download, CheckSquare, Square } from 'lucide-react';
import { clsx } from 'clsx';
import JSZip from 'jszip';

function App() {
  const [fonts, setFonts] = useState<FontFile[]>([]);
  const [isDragging, setIsDragging] = useState(false);
  const [bulkFormat, setBulkFormat] = useState<FontFormat>('woff2');
  const [isProcessingBulk, setIsProcessingBulk] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const processFiles = useCallback(async (files: FileList | File[]) => {
    const newFonts: FontFile[] = Array.from(files).map(file => ({
      id: crypto.randomUUID(),
      file,
      previewUrl: URL.createObjectURL(file),
      metadata: null,
      status: 'loading',
      selected: true
    }));

    setFonts(prev => [...newFonts, ...prev]);

    // Process individually
    newFonts.forEach(async (fontItem) => {
      try {
        const { font, metadata } = await parseFontFile(fontItem.file);
        setFonts(prev => prev.map(f => 
          f.id === fontItem.id 
            ? { ...f, status: 'ready', metadata, parsedFont: font } 
            : f
        ));
      } catch (err) {
        console.error(err);
        setFonts(prev => prev.map(f => 
          f.id === fontItem.id 
            ? { ...f, status: 'error', errorMsg: 'Invalid or unsupported font format.' } 
            : f
        ));
      }
    });
  }, []);

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files?.length) {
      processFiles(e.dataTransfer.files);
    }
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files?.length) {
      processFiles(e.target.files);
    }
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const removeFont = (id: string) => {
    setFonts(prev => {
        const target = prev.find(f => f.id === id);
        if (target) URL.revokeObjectURL(target.previewUrl);
        return prev.filter(f => f.id !== id);
    });
  };

  const toggleSelect = (id: string) => {
    setFonts(prev => prev.map(f => f.id === id ? { ...f, selected: !f.selected } : f));
  };

  const toggleSelectAll = () => {
    const allSelected = fonts.every(f => f.selected);
    setFonts(prev => prev.map(f => ({ ...f, selected: !allSelected })));
  };

  const handleBulkDownload = async () => {
    const selectedFonts = fonts.filter(f => f.selected && f.status === 'ready');
    if (selectedFonts.length === 0) return;

    setIsProcessingBulk(true);
    try {
        const zip = new JSZip();
        
        for (const font of selectedFonts) {
            if (font.parsedFont) {
                const result = await convertFont(font.parsedFont, bulkFormat);
                zip.file(result.fileName, result.buffer);
            }
        }

        const blob = await zip.generateAsync({ type: 'blob' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        
        // Detailed naming convention
        const dateStr = new Date().toISOString().split('T')[0]; // YYYY-MM-DD
        const countStr = selectedFonts.length + 'files';
        a.download = `ConvertedFonts_${bulkFormat.toUpperCase()}_${countStr}_${dateStr}.zip`;
        
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    } catch (e) {
        console.error("Bulk export failed", e);
        alert("Failed to generate zip file. See console for details.");
    } finally {
        setIsProcessingBulk(false);
    }
  };

  const selectedCount = fonts.filter(f => f.selected).length;

  return (
    <div className="min-h-screen flex flex-col font-sans selection:bg-secondary selection:text-brand-900 bg-white">
      {/* Header */}
      <header className="border-b-2 border-gray-200 bg-white sticky top-0 z-50">
        <div className="max-w-5xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="bg-brand-500 p-2 border-2 border-brand-900 shadow-[3px_3px_0px_0px_rgba(6,50,77,1)]">
              <Type className="w-5 h-5 text-white" />
            </div>
            <h1 className="text-xl font-extrabold tracking-tight text-dark-900 uppercase">
              Font <span className="text-brand-500">Converter</span>
            </h1>
          </div>
          <a href="https://github.com" target="_blank" rel="noreferrer" className="text-sm font-bold text-gray-400 hover:text-brand-500 transition-colors uppercase tracking-wider">
            GitHub
          </a>
        </div>
      </header>

      <main className="flex-1 max-w-5xl mx-auto px-4 py-12 w-full">
        {/* Intro */}
        <div className="text-center mb-12 space-y-4">
          <h2 className="text-4xl md:text-6xl font-extrabold text-dark-900 leading-tight">
            Universal <span className="text-brand-500">Font</span> Tool
          </h2>
          <p className="text-gray-500 max-w-2xl mx-auto text-lg font-medium">
            Convert TTF, OTF, WOFF, WOFF2, SVG, & EOT instantly in your browser.<br className="hidden md:block"/>
            Simple, fast, and secure local conversion.
          </p>
        </div>

        {/* Upload Zone */}
        <div 
          className={clsx(
            "relative group border-2 border-dashed transition-all duration-200 p-12 text-center cursor-pointer mb-12 bg-offwhite",
            isDragging 
              ? "border-brand-500 bg-brand-50" 
              : "border-gray-300 hover:border-brand-500 hover:bg-white"
          )}
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
          onClick={() => fileInputRef.current?.click()}
        >
          <input 
            type="file" 
            ref={fileInputRef}
            className="hidden" 
            multiple 
            accept=".ttf,.otf,.woff,.woff2"
            onChange={handleFileInput}
          />
          
          <div className="flex flex-col items-center gap-6">
            <div className={clsx(
                "w-20 h-20 flex items-center justify-center transition-colors duration-200 border-2",
                isDragging ? "bg-brand-500 text-white border-brand-500" : "bg-white text-gray-400 border-gray-300 group-hover:text-brand-500 group-hover:border-brand-500"
            )}>
                <Upload className="w-8 h-8" />
            </div>
            <div className="space-y-2">
                <p className="text-xl font-bold text-dark-900">
                    {isDragging ? 'Drop fonts here' : 'Click or drag to upload fonts'}
                </p>
                <p className="text-sm font-medium text-gray-500 uppercase tracking-wide">
                    Supports TTF, OTF, WOFF, WOFF2
                </p>
            </div>
          </div>
        </div>

        {/* Bulk Actions Toolbar */}
        {fonts.length > 0 && (
            <div className="sticky top-20 z-40 mb-6 bg-white border-2 border-gray-200 p-4 flex flex-wrap items-center justify-between gap-4 shadow-lg">
                <div className="flex items-center gap-4">
                    <button 
                        onClick={toggleSelectAll}
                        className="flex items-center gap-2 text-sm font-bold text-gray-500 hover:text-brand-500 px-2 uppercase tracking-wide"
                    >
                        {fonts.every(f => f.selected) ? <CheckSquare className="w-5 h-5 text-brand-500"/> : <Square className="w-5 h-5"/>}
                        Select All
                    </button>
                    <span className="text-gray-300">|</span>
                    <span className="text-sm font-bold text-brand-600">{selectedCount} selected</span>
                </div>
                
                <div className="flex items-center gap-3">
                    <span className="text-sm font-bold text-gray-500 hidden sm:inline uppercase tracking-wide">Convert selected to:</span>
                    <select 
                        value={bulkFormat}
                        onChange={(e) => setBulkFormat(e.target.value as FontFormat)}
                        className="bg-offwhite border-2 border-gray-200 text-sm px-4 py-2 focus:ring-2 focus:ring-brand-500 focus:outline-none text-dark-900 font-bold uppercase cursor-pointer hover:border-brand-500"
                    >
                        <option value="woff2">WOFF2</option>
                        <option value="woff">WOFF</option>
                        <option value="ttf">TTF</option>
                        <option value="otf">OTF</option>
                        <option value="svg">SVG</option>
                        <option value="eot">EOT</option>
                    </select>
                    <Button 
                        variant="secondary"
                        size="md" 
                        onClick={handleBulkDownload} 
                        disabled={selectedCount === 0}
                        loading={isProcessingBulk}
                    >
                        <Download className="w-4 h-4 mr-2" />
                        Download ZIP
                    </Button>
                </div>
            </div>
        )}

        {/* Font List */}
        <div className="space-y-6">
            {fonts.length > 0 && (
                <div className="flex items-center justify-between text-sm font-medium text-gray-500 mb-2 px-1">
                    <span className="uppercase tracking-wide">Processing {fonts.length} file{fonts.length !== 1 ? 's' : ''}</span>
                    <button onClick={() => setFonts([])} className="hover:text-accent font-bold uppercase tracking-wide transition-colors">Clear all</button>
                </div>
            )}
            
            {fonts.map(font => (
                <FontCard 
                    key={font.id} 
                    fontFile={font} 
                    onRemove={removeFont} 
                    onToggleSelect={toggleSelect}
                />
            ))}

            {fonts.length === 0 && (
                <div className="text-center py-16 border-2 border-dashed border-offwhite bg-white">
                    <div className="flex flex-col items-center gap-3 text-gray-300">
                        <AlertCircle className="w-12 h-12" />
                        <p className="font-bold text-lg">No fonts uploaded yet.</p>
                    </div>
                </div>
            )}
        </div>
      </main>
      
      <footer className="border-t-2 border-gray-100 bg-offwhite py-8 text-center text-gray-500 text-sm font-medium">
        <p className="uppercase tracking-wide">© {new Date().getFullYear()} Font Converter. Powered by opentype.js.</p>
      </footer>
    </div>
  );
}

export default App;