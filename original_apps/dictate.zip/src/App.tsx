import React, { useState, useEffect, useRef } from 'react';
import { Mic, MicOff, Copy, Trash2, Check, AlertCircle, Bold, Italic, Underline, Minus, Plus, Undo, Redo, Volume2, Square, Search, X } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useSpeechRecognition } from './hooks/useSpeechRecognition';
import { useHistory } from './hooks/useHistory';
import { useSpeechSynthesis } from './hooks/useSpeechSynthesis';

const replaceInTextNodes = (node: Node, find: string, replace: string) => {
  if (node.nodeType === Node.TEXT_NODE) {
    if (node.nodeValue) {
      const escapeRegExp = (string: string) => string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      const regex = new RegExp(escapeRegExp(find), 'gi');
      node.nodeValue = node.nodeValue.replace(regex, replace);
    }
  } else {
    node.childNodes.forEach(child => replaceInTextNodes(child, find, replace));
  }
};

export default function App() {
  const {
    isListening,
    transcript,
    interimTranscript,
    toggleListening,
    resetTranscript,
    setTranscript,
    error,
    isSupported
  } = useSpeechRecognition();

  const [copied, setCopied] = useState(false);
  const [fontSize, setFontSize] = useState(18);
  const [showFindReplace, setShowFindReplace] = useState(false);
  const [findText, setFindText] = useState('');
  const [replaceText, setReplaceText] = useState('');
  const editorRef = useRef<HTMLDivElement>(null);
  const endOfTextRef = useRef<HTMLDivElement>(null);

  const { undo, redo, record, debouncedRecord, canUndo, canRedo } = useHistory('');
  const { isSpeaking, toggleSpeaking, rate, setRate, isSupported: isTTSSupported } = useSpeechSynthesis();
  const isUndoRedoRef = useRef(false);

  // Watch transcript changes to record history
  useEffect(() => {
    if (isUndoRedoRef.current) {
      isUndoRedoRef.current = false;
      return;
    }
    debouncedRecord(transcript);
  }, [transcript, debouncedRecord]);

  // Sync transcript to editor
  useEffect(() => {
    if (editorRef.current && editorRef.current.innerHTML !== transcript) {
      editorRef.current.innerHTML = transcript;
    }
  }, [transcript]);

  // Auto-scroll to bottom when dictating
  useEffect(() => {
    if (isListening && endOfTextRef.current) {
      endOfTextRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [transcript, interimTranscript, isListening]);

  const applyFormat = (command: string) => {
    document.execCommand(command, false, undefined);
    if (editorRef.current) {
      const newHtml = editorRef.current.innerHTML;
      setTranscript(newHtml);
      record(newHtml);
      isUndoRedoRef.current = true;
    }
    editorRef.current?.focus();
  };

  const handleReset = () => {
    resetTranscript();
    record('');
    isUndoRedoRef.current = true;
  };

  const handleUndo = () => {
    const previous = undo();
    if (previous !== null) {
      isUndoRedoRef.current = true;
      setTranscript(previous);
    }
  };

  const handleRedo = () => {
    const next = redo();
    if (next !== null) {
      isUndoRedoRef.current = true;
      setTranscript(next);
    }
  };

  const handleReplaceAll = () => {
    if (!findText || !transcript) return;
    const tempDiv = document.createElement('div');
    tempDiv.innerHTML = transcript;
    replaceInTextNodes(tempDiv, findText, replaceText);
    const newHtml = tempDiv.innerHTML;
    setTranscript(newHtml);
    record(newHtml);
    isUndoRedoRef.current = true;
  };

  const handleCopy = async () => {
    if (!editorRef.current) return;
    const html = editorRef.current.innerHTML;
    const text = editorRef.current.innerText;
    if (!text) return;

    try {
      await navigator.clipboard.write([
        new ClipboardItem({
          'text/html': new Blob([html], { type: 'text/html' }),
          'text/plain': new Blob([text], { type: 'text/plain' }),
        })
      ]);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const increaseFontSize = () => setFontSize(prev => Math.min(prev + 2, 48));
  const decreaseFontSize = () => setFontSize(prev => Math.max(prev - 2, 12));

  return (
    <div className="min-h-screen flex flex-col bg-white selection:bg-brand-yellow/50 selection:text-zinc-900">
      {/* Header */}
      <header className="w-full max-w-4xl mx-auto p-6 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-brand-primary flex items-center justify-center text-white">
            <Mic className="w-6 h-6" />
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-zinc-900 uppercase">Dictate</h1>
        </div>
        
        {/* Status indicator */}
        <div className="flex items-center gap-2 text-sm font-bold uppercase tracking-wider">
          {isListening ? (
            <span className="flex items-center gap-2 text-brand-red bg-brand-red/10 px-4 py-2">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full bg-brand-red opacity-75"></span>
                <span className="relative inline-flex h-2 w-2 bg-brand-red"></span>
              </span>
              Listening...
            </span>
          ) : (
            <span className="text-zinc-600 bg-brand-offwhite px-4 py-2">
              Ready
            </span>
          )}
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 w-full max-w-4xl mx-auto p-6 flex flex-col gap-6">
        
        {!isSupported && (
          <div className="bg-brand-red/10 text-brand-red p-4 flex items-start gap-3 border border-brand-red/20">
            <AlertCircle className="w-5 h-5 shrink-0 mt-0.5" />
            <p className="text-sm font-bold">
              Your browser doesn't support the Web Speech API. Please try using Chrome, Edge, or Safari for the best experience.
            </p>
          </div>
        )}

        {error && isSupported && (
          <div className="bg-brand-yellow/20 text-zinc-800 p-4 flex items-start gap-3 border border-brand-yellow/50">
            <AlertCircle className="w-5 h-5 shrink-0 mt-0.5" />
            <p className="text-sm font-bold">{error}</p>
          </div>
        )}

        {/* Editor Area */}
        <div className="flex-1 relative flex flex-col bg-brand-offwhite border-2 border-transparent focus-within:border-brand-primary transition-colors duration-200">
          <div className="flex-1 overflow-y-auto flex flex-col relative">
            <div
              ref={editorRef}
              contentEditable
              onInput={(e) => setTranscript(e.currentTarget.innerHTML)}
              onBlur={() => record(transcript)}
              style={{ fontSize: `${fontSize}px` }}
              className="flex-1 w-full p-8 outline-none leading-relaxed text-zinc-900 bg-transparent min-h-[200px] empty:before:content-[attr(data-placeholder)] empty:before:text-zinc-400 empty:before:pointer-events-none empty:before:block"
              spellCheck="false"
              data-placeholder="Click the microphone and start speaking..."
            />
            {interimTranscript && (
              <div 
                style={{ fontSize: `${fontSize}px` }}
                className="px-8 pb-8 pt-0 leading-relaxed text-zinc-500 italic"
              >
                {interimTranscript}
              </div>
            )}
            <div ref={endOfTextRef} />
          </div>

          {/* Find & Replace Bar */}
          <AnimatePresence>
            {showFindReplace && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: 'auto', opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                className="bg-white border-t-2 border-brand-offwhite px-4 py-3 flex flex-wrap items-center gap-3 overflow-hidden"
              >
                <div className="flex items-center gap-2 flex-1 min-w-[200px]">
                  <Search className="w-4 h-4 text-zinc-400" />
                  <input
                    type="text"
                    placeholder="Find..."
                    value={findText}
                    onChange={(e) => setFindText(e.target.value)}
                    className="flex-1 bg-brand-offwhite px-3 py-1.5 text-sm outline-none focus:ring-2 focus:ring-brand-primary/50 text-zinc-900 placeholder:text-zinc-500"
                  />
                </div>
                <div className="flex items-center gap-2 flex-1 min-w-[200px]">
                  <input
                    type="text"
                    placeholder="Replace with..."
                    value={replaceText}
                    onChange={(e) => setReplaceText(e.target.value)}
                    className="flex-1 bg-brand-offwhite px-3 py-1.5 text-sm outline-none focus:ring-2 focus:ring-brand-primary/50 text-zinc-900 placeholder:text-zinc-500"
                  />
                </div>
                <button
                  onClick={handleReplaceAll}
                  disabled={!findText}
                  className="px-4 py-1.5 bg-brand-primary hover:bg-[#156ea6] text-white text-sm font-bold uppercase tracking-wider transition-colors disabled:opacity-50 disabled:hover:bg-brand-primary"
                >
                  Replace All
                </button>
                <button
                  onClick={() => setShowFindReplace(false)}
                  className="p-1.5 text-zinc-400 hover:text-zinc-700 transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Toolbar */}
          <div className="p-4 bg-white border-t-2 border-brand-offwhite flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center flex-wrap gap-4">
              {/* Undo / Redo / Search */}
              <div className="flex items-center gap-1 border-r-2 border-brand-offwhite pr-4">
                <button
                  onClick={handleUndo}
                  disabled={!canUndo}
                  className="p-2 text-zinc-600 hover:bg-brand-offwhite hover:text-brand-primary transition-colors disabled:opacity-30 disabled:hover:bg-transparent disabled:hover:text-zinc-600"
                  title="Undo"
                >
                  <Undo className="w-5 h-5" />
                </button>
                <button
                  onClick={handleRedo}
                  disabled={!canRedo}
                  className="p-2 text-zinc-600 hover:bg-brand-offwhite hover:text-brand-primary transition-colors disabled:opacity-30 disabled:hover:bg-transparent disabled:hover:text-zinc-600"
                  title="Redo"
                >
                  <Redo className="w-5 h-5" />
                </button>
                <button
                  onClick={() => setShowFindReplace(!showFindReplace)}
                  className={`p-2 transition-colors ${showFindReplace ? 'bg-brand-primary text-white' : 'text-zinc-600 hover:bg-brand-offwhite hover:text-brand-primary'}`}
                  title="Find and Replace"
                >
                  <Search className="w-5 h-5" />
                </button>
              </div>

              {/* Formatting */}
              <div className="flex items-center gap-1 border-r-2 border-brand-offwhite pr-4">
                <button
                  onMouseDown={(e) => { e.preventDefault(); applyFormat('bold'); }}
                  className="p-2 text-zinc-600 hover:bg-brand-offwhite hover:text-brand-primary transition-colors"
                  title="Bold"
                >
                  <Bold className="w-5 h-5" />
                </button>
                <button
                  onMouseDown={(e) => { e.preventDefault(); applyFormat('italic'); }}
                  className="p-2 text-zinc-600 hover:bg-brand-offwhite hover:text-brand-primary transition-colors"
                  title="Italic"
                >
                  <Italic className="w-5 h-5" />
                </button>
                <button
                  onMouseDown={(e) => { e.preventDefault(); applyFormat('underline'); }}
                  className="p-2 text-zinc-600 hover:bg-brand-offwhite hover:text-brand-primary transition-colors"
                  title="Underline"
                >
                  <Underline className="w-5 h-5" />
                </button>
              </div>

              {/* Font Size */}
              <div className="flex items-center gap-1 border-r-2 border-brand-offwhite pr-4">
                <button
                  onClick={decreaseFontSize}
                  className="p-2 text-zinc-600 hover:bg-brand-offwhite hover:text-brand-primary transition-colors"
                  title="Decrease Font Size"
                >
                  <Minus className="w-5 h-5" />
                </button>
                <span className="w-10 text-center font-bold text-sm text-zinc-700">{fontSize}px</span>
                <button
                  onClick={increaseFontSize}
                  className="p-2 text-zinc-600 hover:bg-brand-offwhite hover:text-brand-primary transition-colors"
                  title="Increase Font Size"
                >
                  <Plus className="w-5 h-5" />
                </button>
              </div>

              {/* Playback Speed & Read Aloud */}
              {isTTSSupported && (
                <div className="flex items-center gap-3 border-r-2 border-brand-offwhite pr-4">
                  <button
                    onClick={() => toggleSpeaking(transcript)}
                    disabled={!transcript && !interimTranscript}
                    className={`p-2 transition-colors ${
                      isSpeaking 
                        ? 'text-brand-red bg-brand-red/10 hover:bg-brand-red/20' 
                        : 'text-zinc-600 hover:bg-brand-offwhite hover:text-brand-primary'
                    } disabled:opacity-30 disabled:hover:bg-transparent disabled:hover:text-zinc-600`}
                    title={isSpeaking ? "Stop Reading" : "Read Aloud"}
                  >
                    {isSpeaking ? <Square className="w-5 h-5 fill-current" /> : <Volume2 className="w-5 h-5" />}
                  </button>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-zinc-500 uppercase tracking-wider">Speed</span>
                    <input
                      type="range"
                      min="0.5"
                      max="2"
                      step="0.1"
                      value={rate}
                      onChange={(e) => setRate(parseFloat(e.target.value))}
                      className="w-20 accent-brand-primary"
                      title={`Playback Speed: ${rate}x`}
                    />
                    <span className="text-xs font-bold text-zinc-700 w-8">{rate.toFixed(1)}x</span>
                  </div>
                </div>
              )}

              <button
                onClick={handleReset}
                disabled={!transcript && !interimTranscript}
                className="p-2 text-zinc-500 hover:text-brand-red hover:bg-brand-red/10 transition-colors disabled:opacity-50 disabled:hover:bg-transparent disabled:hover:text-zinc-500"
                title="Clear text"
              >
                <Trash2 className="w-5 h-5" />
              </button>
            </div>

            <div className="flex items-center gap-3">
              <button
                onClick={handleCopy}
                disabled={!transcript}
                className="flex items-center gap-2 px-6 py-3 font-bold uppercase tracking-wider text-sm text-zinc-900 bg-brand-yellow hover:bg-[#e6b634] transition-colors disabled:opacity-50 disabled:hover:bg-brand-yellow"
              >
                {copied ? (
                  <>
                    <Check className="w-4 h-4" />
                    <span>Copied!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-4 h-4" />
                    <span>Copy Text</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Primary Action */}
        <div className="flex justify-center pb-8 pt-4">
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={toggleListening}
            disabled={!isSupported}
            className={`
              relative group flex items-center justify-center w-24 h-24 transition-colors disabled:opacity-50 disabled:cursor-not-allowed
              ${isListening 
                ? 'bg-brand-red hover:bg-[#e0484d] text-white' 
                : 'bg-brand-primary hover:bg-[#156ea6] text-white'
              }
            `}
          >
            {/* Pulse effect when listening */}
            {isListening && (
              <span className="absolute inset-0 bg-brand-red animate-ping opacity-20"></span>
            )}
            
            {isListening ? (
              <MicOff className="w-10 h-10" />
            ) : (
              <Mic className="w-10 h-10" />
            )}
          </motion.button>
        </div>
      </main>
    </div>
  );
}
