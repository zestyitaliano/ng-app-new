import React from 'react';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'outline' | 'danger';
  icon?: React.ReactNode;
}

export const Button: React.FC<ButtonProps> = ({ 
  children, 
  variant = 'primary', 
  className = '', 
  icon,
  ...props 
}) => {
  const baseStyles = "inline-flex items-center justify-center gap-2 px-6 py-3 text-sm font-bold uppercase tracking-wide transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed border-2";
  
  const variants = {
    primary: "bg-primary border-primary text-white hover:bg-blue-600 hover:border-blue-600 focus:ring-primary",
    secondary: "bg-secondary border-secondary text-slate-900 hover:bg-yellow-400 hover:border-yellow-400 focus:ring-secondary",
    outline: "bg-white border-slate-200 text-slate-700 hover:border-primary hover:text-primary focus:ring-primary",
    danger: "bg-danger border-danger text-white hover:bg-red-600 hover:border-red-600 focus:ring-danger",
  };

  return (
    <button 
      className={`${baseStyles} ${variants[variant]} ${className}`} 
      {...props}
    >
      {icon}
      {children}
    </button>
  );
};