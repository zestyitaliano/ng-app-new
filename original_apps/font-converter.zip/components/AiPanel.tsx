import React, { useState } from 'react';
import { FontMetadata, AiActionType } from '../types';
import { generateFontInsights } from '../services/geminiService';
import { Button } from './Button';
import { Sparkles, Palette, Code, Info } from 'lucide-react';
import ReactMarkdown from 'react-markdown';

interface AiPanelProps {
  metadata: FontMetadata;
}

export const AiPanel: React.FC<AiPanelProps> = ({ metadata }) => {
  const [activeTab, setActiveTab] = useState<AiActionType | null>(null);
  const [content, setContent] = useState<Record<AiActionType, string>>({
    [AiActionType.PAIRINGS]: '',
    [AiActionType.CSS]: '',
    [AiActionType.VIBE]: '',
  });
  const [loading, setLoading] = useState(false);

  const handleAction = async (type: AiActionType) => {
    setActiveTab(type);
    if (content[type]) return; // Use cached result

    setLoading(true);
    try {
      const result = await generateFontInsights(metadata, type);
      setContent(prev => ({ ...prev, [type]: result }));
    } catch (e) {
      setContent(prev => ({ ...prev, [type]: 'Error generating insight.' }));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-offwhite border border-gray-200 p-6 mt-6">
      <div className="flex items-center gap-2 mb-4">
        <Sparkles className="w-5 h-5 text-brand-500" />
        <h3 className="text-lg font-bold text-dark-900 uppercase">AI Design Assistant</h3>
      </div>
      
      <div className="flex flex-wrap gap-2 mb-6">
        <Button 
          variant={activeTab === AiActionType.PAIRINGS ? 'primary' : 'outline'} 
          size="sm"
          onClick={() => handleAction(AiActionType.PAIRINGS)}
        >
          <Info className="w-4 h-4 mr-2" />
          Get Pairings
        </Button>
        <Button 
          variant={activeTab === AiActionType.CSS ? 'primary' : 'outline'} 
          size="sm"
          onClick={() => handleAction(AiActionType.CSS)}
        >
          <Code className="w-4 h-4 mr-2" />
          Generate CSS
        </Button>
        <Button 
          variant={activeTab === AiActionType.VIBE ? 'primary' : 'outline'} 
          size="sm"
          onClick={() => handleAction(AiActionType.VIBE)}
        >
          <Palette className="w-4 h-4 mr-2" />
          Vibe Check
        </Button>
      </div>

      {activeTab && (
        <div className="bg-white p-4 border border-gray-200 min-h-[200px] text-dark-800 text-sm leading-relaxed overflow-x-auto shadow-sm">
          {loading ? (
            <div className="flex flex-col items-center justify-center h-full py-12 text-gray-500 gap-3">
              <Sparkles className="w-8 h-8 animate-pulse text-secondary" />
              <p>Gemini is thinking...</p>
            </div>
          ) : (
            <div className="markdown-prose prose prose-slate max-w-none">
              <ReactMarkdown 
                components={{
                  code({node, inline, className, children, ...props}: any) {
                    return !inline ? (
                      <pre className="bg-offwhite p-3 border border-gray-200 overflow-x-auto my-2 text-dark-900">
                        <code {...props} className={className}>
                          {children}
                        </code>
                      </pre>
                    ) : (
                      <code className="bg-offwhite px-1 py-0.5 border border-gray-200 text-brand-600 font-mono text-xs" {...props}>
                        {children}
                      </code>
                    )
                  }
                }}
              >
                {content[activeTab]}
              </ReactMarkdown>
            </div>
          )}
        </div>
      )}
    </div>
  );
};