import { GoogleGenAI, Type } from "@google/genai";
import { SectionType } from "../types";

const apiKey = process.env.API_KEY || '';
const ai = new GoogleGenAI({ apiKey });

export const generateLayoutFromDescription = async (description: string): Promise<SectionType[]> => {
  if (!apiKey) {
    console.warn("No API Key provided for Gemini");
    return [SectionType.Hero, SectionType.Feature, SectionType.Contact]; // Fallback
  }

  try {
    const modelId = "gemini-2.5-flash";
    
    const response = await ai.models.generateContent({
      model: modelId,
      contents: `Generate a website section layout for: "${description}". 
      Return a JSON array of section types. 
      Allowed types: Hero, Feature, Gallery, Testimonial, Contact, Footer, Pricing.
      Example: ["Hero", "Feature", "Pricing", "Footer"]`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.STRING,
            enum: Object.values(SectionType)
          }
        }
      }
    });

    const jsonText = response.text;
    if (!jsonText) return [];
    
    const sections = JSON.parse(jsonText) as SectionType[];
    return sections;

  } catch (error) {
    console.error("Gemini API Error:", error);
    return [];
  }
};